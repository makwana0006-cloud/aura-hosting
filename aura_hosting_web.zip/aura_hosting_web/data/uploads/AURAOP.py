import asyncio
import aiohttp
import json
import uuid
import re
import logging
import base64
from telegram import Update, ReplyKeyboardMarkup, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters
from telegram.error import Forbidden, BadRequest, TelegramError

# --- LOGGING ---
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# --- CONFIGURATION ---
BOT_TOKEN = "8625658152:AAEZJJP9XVUrOEqsWsytdFytRRNYfwgi9pg"
ADMIN_ID = 6566593716 
ADMIN_USERNAME = "@Yourr_aura" 


_ENC_URL = "aHR0cHM6Ly91c2Vycy14aW5mby1hZG1pbi52ZXJjZWwuYXBwL2FwaT9rZXk9MjAwMTBtYXImdHlwZT1tb2JpbGUmdGVybT0="

def get_api_url(term):
    """Decodes the hidden API URL at runtime."""
    base = base64.b64decode(_ENC_URL).decode('utf-8')
    return f"{base}{term}"

# --- IN-MEMORY DATABASE ---
user_db = {}
redeem_codes = {} 

# --- HELPER FUNCTIONS ---

def escape_markdown(text):
    """Helper to escape all reserved characters for MarkdownV2."""
    escape_chars = r'_*[]()~`>#+-=|{}.!=\\' 
    return re.sub(f'([{re.escape(escape_chars)}])', r'\\\1', str(text))

def get_user_data(user_id):
    uid = str(user_id)
    is_new = False
    if uid not in user_db:
        is_new = True
        initial_credits = 999999 if int(user_id) == ADMIN_ID else 3 
        user_db[uid] = {
            "credits": initial_credits, 
            "referrals": 0,
            "searches_done": 0,
            "state": None,
            "target_id": None
        }
    return user_db[uid], is_new

def get_main_keyboard(user_id):
    buttons = [
        ["📱 Phone Lookup"], 
        ["👤 My Account", "🎁 Earn Credits"],
        ["🎟 Redeem Code", "💰 Buy Credits"]
    ]
    if int(user_id) == ADMIN_ID:
        buttons.append(["⚙️ Admin Panel"])
    return ReplyKeyboardMarkup(buttons, resize_keyboard=True)

def get_admin_keyboard():
    return ReplyKeyboardMarkup([
        ["📊 Total Users", "🎫 Gen Redeem Code"],
        ["➕ Add Credits Manually", "📢 Broadcast"],
        ["🔙 Back to Menu"]
    ], resize_keyboard=True)

# --- HANDLERS ---

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_name = update.effective_user.username or update.effective_user.first_name
    safe_name = escape_markdown(user_name)
    user_data, is_new = get_user_data(user_id)
    
    if is_new and context.args and context.args[0]:
        ref_id = context.args[0]
        if ref_id.isdigit() and int(ref_id) != user_id:
            r_data, _ = get_user_data(int(ref_id))
            r_data["referrals"] += 1
            r_data["credits"] += 1 
            try:
                await context.bot.send_message(
                    chat_id=int(ref_id), 
                    text=fr"🔔 *New Referral\!*" + "\n" + fr"User joined\. You got *1 Credit*\!",
                    parse_mode=ParseMode.MARKDOWN_V2
                )
            except: pass

    welcome_msg = (
        f"👋 *Hey {safe_name}\! Welcome to Aura Lookup Bot*" if is_new else f"👋 *Hey {safe_name}\! Welcome Back\!*"
    )
    welcome_msg += "\n\nSend a 10\-digit number to start searching\."
        
    await update.message.reply_text(welcome_msg, parse_mode=ParseMode.MARKDOWN_V2, reply_markup=get_main_keyboard(user_id))

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not update.message or not update.message.text:
        return
        
    text = update.message.text.strip()
    user_data, _ = get_user_data(user_id)

    # --- ADMIN ACTIONS ---
    if int(user_id) == ADMIN_ID:
        if text == "⚙️ Admin Panel":
            user_data["state"] = None
            await update.message.reply_text(r"🛠 *Admin Control Center:*", parse_mode=ParseMode.MARKDOWN_V2, reply_markup=get_admin_keyboard())
            return
        
        if text == "🔙 Back to Menu":
            user_data["state"] = None
            await update.message.reply_text("Returning to main menu...", reply_markup=get_main_keyboard(user_id))
            return
            
        if text == "📊 Total Users":
            await update.message.reply_text(fr"📊 Total Users: `{len(user_db)}`", parse_mode=ParseMode.MARKDOWN_V2)
            return

        if text == "🎫 Gen Redeem Code":
            user_data["state"] = "W_AMT"
            await update.message.reply_text("Enter credit amount for code:")
            return

        if user_data["state"] == "W_AMT" and text.isdigit():
            code = f"AURA-{uuid.uuid4().hex[:6].upper()}"
            redeem_codes[code] = int(text)
            user_data["state"] = None
            await update.message.reply_text(fr"✅ Code Generated: `{code}`\nValue: {text} Credits", parse_mode=ParseMode.MARKDOWN_V2)
            return

        if text == "➕ Add Credits Manually":
            user_data["state"] = "WAIT_USER_ID"
            await update.message.reply_text("Enter the User ID to add credits to:")
            return

        if user_data["state"] == "WAIT_USER_ID":
            user_data["target_id"] = text
            user_data["state"] = "WAIT_CREDIT_AMT"
            await update.message.reply_text(f"Enter amount of credits for User `{text}`:", parse_mode=ParseMode.MARKDOWN_V2)
            return

        if user_data["state"] == "WAIT_CREDIT_AMT" and text.isdigit():
            target_uid = user_data["target_id"]
            amount = int(text)
            t_data, _ = get_user_data(target_uid)
            t_data["credits"] += amount
            user_data["state"] = None
            await update.message.reply_text(fr"✅ Success\! Added `{amount}` credits to `{target_uid}`\.", parse_mode=ParseMode.MARKDOWN_V2)
            try:
                await context.bot.send_message(chat_id=int(target_uid), text=fr"🎁 Admin added *{amount} Credits* to your account\!", parse_mode=ParseMode.MARKDOWN_V2)
            except: pass
            return

        if text == "📢 Broadcast":
            user_data["state"] = "WAIT_BROADCAST"
            await update.message.reply_text("Please send the message you want to broadcast to all users. (Text only)")
            return

        if user_data["state"] == "WAIT_BROADCAST":
            user_data["state"] = None
            all_users = list(user_db.keys())
            count = 0
            fail = 0
            status_msg = await update.message.reply_text(f"🚀 Starting broadcast to {len(all_users)} users...")
            
            for uid in all_users:
                try:
                    await context.bot.send_message(chat_id=int(uid), text=text)
                    count += 1
                    await asyncio.sleep(0.05) 
                except Forbidden:
                    fail += 1 
                except Exception:
                    fail += 1
            
            await status_msg.edit_text(f"✅ *Broadcast Finished*\n\nTotal: {len(all_users)}\nSuccess: {count}\nFailed/Blocked: {fail}")
            return

    # --- REDEEM CODE LOGIC ---
    if text == "🎟 Redeem Code":
        user_data["state"] = "WAIT_REDEEM"
        await update.message.reply_text(r"🎟 *Enter your Redeem Code:*", parse_mode=ParseMode.MARKDOWN_V2)
        return

    if user_data["state"] == "WAIT_REDEEM":
        code = text.upper()
        if code in redeem_codes:
            amt = redeem_codes.pop(code)
            user_data["credits"] += amt
            user_data["state"] = None
            await update.message.reply_text(fr"✅ *Successfully Redeemed\!*" + "\n" + fr"You received *{amt} Credits*\.", parse_mode=ParseMode.MARKDOWN_V2)
        else:
            user_data["state"] = None
            await update.message.reply_text(r"❌ *Invalid or Expired Code\.*", parse_mode=ParseMode.MARKDOWN_V2)
        return

    # --- USER UI ---
    if text == "👤 My Account":
        cred = "Unlimited" if user_id == ADMIN_ID else str(user_data['credits'])
        msg = (
            r"👤 *MY ACCOUNT*" + "\n\n"
            r"╭───────────────────" + "\n"
            f"│ 💎 Your Credits: *{escape_markdown(cred)}* ❞" + "\n"
            f"│ 👥 Referrals: *{user_data['referrals']}*" + "\n"
            f"│ 🔍 Searches Done: *{user_data['searches_done']}*" + "\n"
            r"╰───────────────────"
        )
        await update.message.reply_text(msg, parse_mode=ParseMode.MARKDOWN_V2)
        return

    if text == "🎁 Earn Credits":
        bot = await context.bot.get_me()
        link = f"https://t\.me/{escape_markdown(bot.username)}?start\={user_id}"
        msg = (
            r"💖 *REFERRAL PROGRAM*" + "\n\n"
            r"Invite friends and earn credits\!" + "\n"
            r"Each referral \= \+1 credit instantly\!" + "\n\n"
            r"*Your Referral Link:*" + "\n"
            f"{link}" + "\n\n"
            r"╭───────────────────" + "\n"
            f"│ Total Referrals: *{user_data['referrals']}* ❞" + "\n"
            f"│ Credits Earned: *{user_data['referrals']} Credits*" + "\n"
            f"│ Your Balance: *{user_data['credits']} Credits*" + "\n"
            r"╰───────────────────"
        )
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("📤 Share Link", switch_inline_query=f"\nJoin this bot! https://t.me/{bot.username}?start={user_id}")]])
        await update.message.reply_text(msg, parse_mode=ParseMode.MARKDOWN_V2, reply_markup=kb)
        return

    if text == "💰 Buy Credits":
        admin_raw = ADMIN_USERNAME.replace('@', '')
        msg = (
            r"💎 *BUY CREDITS*" + "\n"
            r"━━━━━━━━━━━━━━━━━━━━" + "\n\n"
            r"🥉 *Basic*" + "\n" + r"1 Day Unlimited • ₹50" + "\n\n"
            r"🥈 *Premium*" + "\n" + r"5 Day Unlimited • ₹150" + "\n\n"
            r"🥇 *VIP*" + "\n" + r"10 Day Unlimited • ₹200" + "\n\n"
            r"━━━━━━━━━━━━━━━━━━━━"
        )
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("💎 Buy Premium", url=f"https://t.me/{admin_raw}")]])
        await update.message.reply_text(msg, parse_mode=ParseMode.MARKDOWN_V2, reply_markup=kb)
        return

    # --- LOOKUP LOGIC ---
    if text.isdigit() and len(text) == 10:
        if user_id != ADMIN_ID and user_data['credits'] < 1:
            err = (
                r"❌ *NOT ENOUGH CREDITS*" + "\n\n"
                r"_You need 1 credit to search\._" + "\n\n"
                r"╭───────────────────" + "\n"
                f"│ Your Balance: *{user_data['credits']} Credit* ❞" + "\n"
                r"│ Need: *1 More Credit*" + "\n"
                r"╰───────────────────" + "\n\n"
                r"🎁 *Quick Earn:*" + "\n"
                r"👉 Invite 3 friends \= Get 3 credits *FREE*" + "\n"
                r"👉 Then search instantly\!"
            )
            admin_raw = ADMIN_USERNAME.replace('@', '')
            kb = InlineKeyboardMarkup([
                [InlineKeyboardButton("🎁 Get Referral Link", callback_data="get_ref")],
                [InlineKeyboardButton("💰 Buy Credits", url=f"https://t.me/{admin_raw}")]
            ])
            await update.message.reply_text(err, parse_mode=ParseMode.MARKDOWN_V2, reply_markup=kb)
            return

        status_msg = await update.message.reply_text(fr"🔍 Fetching info for {text}\.\.\.", parse_mode=ParseMode.MARKDOWN_V2)

        try:
            async with aiohttp.ClientSession() as session:
                # Using the hidden API function
                async with session.get(get_api_url(text), timeout=15) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        if data.get("success") or data.get("status") == True:
                            if user_id != ADMIN_ID:
                                user_data['credits'] -= 1
                            user_data['searches_done'] += 1

                            result_content = data.get("data", data.get("result", {}))
                            
                            # Build exact JSON structure as requested
                            full_response = {
                                "status": True,
                                "data": result_content if isinstance(result_content, list) else [result_content],
                                "credit": "@Yourr_aura"
                            }
                            
                            formatted_json = json.dumps(full_response, indent=2, ensure_ascii=False)
                            
                            result_msg = (
                                fr"🔍 *Lookup Result for {text}*" + "\n\n"
                                fr"```json" + "\n"
                                fr"{escape_markdown(formatted_json)}" + "\n"
                                fr"```"
                            )
                            
                            # Inline button to copy logic (Telegram clients handle code blocks as copyable)
                            kb = InlineKeyboardMarkup([[InlineKeyboardButton("📋 Copy JSON", callback_data=f"copy_{text}")]])
                            
                            await status_msg.edit_text(result_msg, parse_mode=ParseMode.MARKDOWN_V2, reply_markup=kb)
                        else:
                            await status_msg.edit_text(r"❌ No data found for this number\.", parse_mode=ParseMode.MARKDOWN_V2)
                    else:
                        await status_msg.edit_text(r"❌ API connection error\.", parse_mode=ParseMode.MARKDOWN_V2)
        except Exception as e:
            await status_msg.edit_text(fr"❌ Error: {escape_markdown(str(e))}", parse_mode=ParseMode.MARKDOWN_V2)
        return

    if text == "📱 Phone Lookup":
        await update.message.reply_text("📱 Send 10 digit mobile number:")

# --- CALLBACKS ---
async def cb(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    if query.data == "get_ref":
        bot = await context.bot.get_me()
        user_id = query.from_user.id
        link = f"https://t\.me/{escape_markdown(bot.username)}?start\={user_id}"
        await query.message.reply_text(fr"🎁 Your Referral Link: `{link}`", parse_mode=ParseMode.MARKDOWN_V2)
    
    elif query.data.startswith("copy_"):
        await query.answer("Tap the JSON code above to copy it!", show_alert=True)

def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.add_handler(CallbackQueryHandler(cb))
    print("Bot is ready! API URL is now hidden.")
    app.run_polling()

if __name__ == "__main__":
    main()