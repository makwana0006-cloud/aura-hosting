from flask import Flask, render_template, request, redirect, session
import os, sqlite3, subprocess, time

app = Flask(__name__)
app.secret_key = "aura_secret"

UPLOAD_FOLDER = "uploads"
LOG_FOLDER = "logs"
MAX_STORAGE = 1024 * 1024 * 1024  # 1GB

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(LOG_FOLDER, exist_ok=True)

processes = {}

# ---------------- USER FOLDER ----------------
def user_folder():
    user = session.get("user")
    path = os.path.join(UPLOAD_FOLDER, user)
    os.makedirs(path, exist_ok=True)
    return path

# ---------------- STORAGE ----------------
def get_user_storage():
    total = 0
    for root, dirs, files in os.walk(user_folder()):
        for f in files:
            total += os.path.getsize(os.path.join(root, f))
    return total

# ---------------- DATABASE ----------------
conn = sqlite3.connect("users.db", check_same_thread=False)
cur = conn.cursor()

cur.execute("CREATE TABLE IF NOT EXISTS users (username TEXT, password TEXT, email TEXT)")
cur.execute("CREATE TABLE IF NOT EXISTS history (user TEXT, file TEXT, time TEXT)")
conn.commit()

# ---------------- HOME ----------------
@app.route("/")
def home():
    return redirect("/dashboard" if "user" in session else "/login")

# ---------------- REGISTER ----------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        cur.execute("INSERT INTO users VALUES (?,?,?)",
                    (request.form["username"], request.form["password"], request.form["email"]))
        conn.commit()
        return redirect("/login")
    return render_template("register.html")

# ---------------- LOGIN ----------------
@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        cur.execute("SELECT * FROM users WHERE username=? AND password=?",
                    (request.form["username"], request.form["password"]))
        if cur.fetchone():
            session["user"] = request.form["username"]
            return redirect("/dashboard")
        else:
            error = "❌ Invalid Login"
    return render_template("login.html", error=error)

# ---------------- DASHBOARD ----------------
@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect("/login")

    files = os.listdir(user_folder())

    status = {}
    for f in files:
        key = session["user"] + f
        status[f] = "Running" if key in processes and processes[key].poll() is None else "Stopped"

    storage = get_user_storage()

    cur.execute("SELECT * FROM history WHERE user=?", (session["user"],))
    history = cur.fetchall()

    return render_template("dashboard.html",
                           files=files,
                           status=status,
                           storage=storage,
                           max_storage=MAX_STORAGE,
                           history=history)

# ---------------- SIMPLE UPLOAD ----------------
@app.route("/upload", methods=["POST"])
def upload():
    if "user" not in session:
        return redirect("/login")

    file = request.files.get("file")

    if file:
        path = user_folder()

        size = len(file.read())
        file.seek(0)

        if get_user_storage() + size > MAX_STORAGE:
            return "❌ Storage Full!"

        file.save(os.path.join(path, file.filename))

        cur.execute("INSERT INTO history VALUES (?,?,?)",
                    (session["user"], file.filename, time.ctime()))
        conn.commit()

    return redirect("/dashboard")

# ---------------- DELETE ----------------
@app.route("/delete/<path:filename>")
def delete_file(filename):
    path = os.path.join(user_folder(), filename)
    if os.path.exists(path):
        os.remove(path)
    return redirect("/dashboard")

# ---------------- PREVIEW ----------------
@app.route("/preview/<path:filename>")
def preview(filename):
    path = os.path.join(user_folder(), filename)
    if os.path.exists(path):
        return "<pre>" + open(path).read()[:5000] + "</pre>"
    return "File not found"

# ---------------- START FILE ----------------
@app.route("/start/<path:filename>")
def start_file(filename):
    path = os.path.join(user_folder(), filename)
    log_path = os.path.join(LOG_FOLDER, filename + ".log")

    log = open(log_path, "w")

    if filename.endswith(".py"):
        cmd = ["python", path]
    elif filename.endswith(".php"):
        cmd = ["php", path]
    else:
        return "Unsupported file type"

    p = subprocess.Popen(cmd, stdout=log, stderr=log)
    processes[session["user"] + filename] = p

    return redirect("/dashboard")

# ---------------- STOP ----------------
@app.route("/stop/<path:filename>")
def stop_file(filename):
    key = session["user"] + filename
    if key in processes:
        processes[key].terminate()
    return redirect("/dashboard")

# ---------------- LOGS ----------------
@app.route("/logs/<path:filename>")
def logs(filename):
    path = os.path.join(LOG_FOLDER, filename + ".log")
    if os.path.exists(path):
        return "<pre>" + open(path).read() + "</pre>"
    return "No logs"

# ---------------- LOGOUT ----------------
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")

# ---------------- RUN ----------------
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)